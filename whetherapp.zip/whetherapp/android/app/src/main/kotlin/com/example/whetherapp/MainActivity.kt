package com.example.whetherapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
